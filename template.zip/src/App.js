
import ProminentAppBar from './components/Appbar';
import Body from './components/Body';

function App() {
  return (
    <div className="App" style={{display:"flex", flexDirection: "column"}}>
      <ProminentAppBar/>
      {/* <Body/> */}
    </div>
  );
}

export default App;
